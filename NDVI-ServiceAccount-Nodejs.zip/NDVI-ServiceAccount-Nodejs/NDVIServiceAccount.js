const ee = require('@google/earthengine');
const express = require('express');
const privateKey = require('./ranjanearthengineapi-dd16038229c6.json');
const port = process.env.PORT || 3000;

// Define endpoint at /mapid.
const app = express().get('/mapid', (_, response) => {
  const srtm = ee.Image('CGIAR/SRTM90_V4');
  const slope = ee.Terrain.slope(srtm);
  slope.getMap({min: 0, max: 60}, ({mapid}) => response.send(mapid));
});

console.log('Authenticating Earth Engine API using private key...');
ee.data.authenticateViaPrivateKey(
    privateKey,
    () => {
      console.log('Authentication successful.');
      ee.initialize(
          null, null,
          () => {
            console.log('Earth Engine client library initialized.');
            app.listen(port);
            console.log(`Listening on port ${port}`);
            /*
	    var countries = ee.FeatureCollection('USDOS/LSIB_SIMPLE/2017');
	    var India = countries.filter(ee.Filter.eq('country_na', 'India'));

	    var Indlandsat = ee.ImageCollection('LANDSAT/LC08/C01/T1_TOA')
	                    .filterDate('2020-01-01','2020-12-31')
                            .filterBounds(India)
                            .median();

            var ndviMethod2 = Indlandsat.normalizedDifference(['B4', 'B3']);


	    var NDVI_Palette = '00FF00, FFFF00, 000000';
            Map.addLayer(ndviMethod2.clip(India),{min: -0.3, max: 0.5,palette: NDVI_Palette}, 'NDVI Method 2');
            Map.addLayer(India, {}, 'India NDVI', false);
            Map.centerObject(India, 5);

            console.log('image='+ndviMethod2.normalizedDifference);
            */
           //Start Of NDVI Code
           
           var geometry2 = ee.Geometry.Polygon(
        [[[68.42868891329321, 34.46613848578473],
          [68.42868891329321, 8.423868757081069],
          [97.87204828829321, 8.423868757081069],
          [97.87204828829321, 34.46613848578473]]], null, false);

var countries = ee.FeatureCollection('USDOS/LSIB_SIMPLE/2017');
var India = countries.filter(ee.Filter.eq('country_na', 'India'));

var tlNDVIForIndia = ee.ImageCollection('MODIS/006/MOD13A2').select('NDVI')
.filterDate('2018-01-01','2020-12-31')
.filterBounds(India);

tlNDVIForIndia = tlNDVIForIndia.map(function(img) {
  var doy = ee.Date(img.get('system:time_start')).getRelative('day', 'year');
  return img.set('doy', doy);
});
var distinctDOY = tlNDVIForIndia.filterDate('2018-01-01', '2018-12-01');
var filter = ee.Filter.equals({leftField: 'doy', rightField: 'doy'});
var join = ee.Join.saveAll('doy_matches');
var joinCol = ee.ImageCollection(join.apply(distinctDOY, tlNDVIForIndia, filter));

var comp = joinCol.map(function(img) {
  var doyCol = ee.ImageCollection.fromImages(
    img.get('doy_matches')
  );
  return doyCol.reduce(ee.Reducer.median());
});



var visParamsForTL = {
  min: 0.0,
  max: 9000.0,
  palette: [
    'FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901',
    '66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',
    '012E01', '011D01', '011301'
  ],
};



var rgbVis = comp.map(function(img) {
  return img.visualize(visParamsForTL);
});

var gifParams = {
 'region': geometry2,
  'dimensions': 600,
  'crs': 'EPSG:3857',
  'framesPerSecond': 10
};

console.log(rgbVis.getVideoThumbURL(gifParams));


    
           //End Of NDVI Code

          },
          (err) => {
            console.log(err);
            console.log(
                `Please make sure you have created a service account and have been approved.
Visit https://developers.google.com/earth-engine/service_account#how-do-i-create-a-service-account to learn more.`);
          });
    },
    (err) => {
      console.log(err);
    });
