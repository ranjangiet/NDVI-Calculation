# NDVI calculation using Google Earth Engine client library , Service Account and NodeJs

This code is ysed to calculate NDVI of India location from year 2018 to 2021.

To set the app up yourself, download the NDVI-ServiceAccount-Nodejs from
GitHub:

Navigate to the NDVI-ServiceAccount-Nodejs folder:

Then follow the instructions in the Developer Docs to
[deploy an EE-based App Engine app](https://developers.google.com/earth-engine/app_engine_intro#deploying-app-engine-apps-with-earth-engine).
For the credentials section, you'll need a Service Account, not an OAuth2 Client
ID. Next:

1.  Downloaded Service Account JSON private key file and move it into the `NDVI-ServiceAccount-Nodejs folder.
2.  Un line 3 of NDVIServiceAccount.js file replace your downloaded json file name with myserviceaccount.json' in 
    const privateKey = require('./myserviceaccount.json').
3.  Run the code using 'node NDVIServiceAccount.js' command

